package com.abir.fitness
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.content.Intent
import android.net.Uri
class MainActivity: Activity() {
 private lateinit var web: WebView
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); web=WebView(this); setContentView(web); web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.settings.mediaPlaybackRequiresUserGesture=true
 web.webViewClient=object:WebViewClient(){ override fun shouldOverrideUrlLoading(view:WebView, request:WebResourceRequest):Boolean { val u=request.url; return if(u.host?.contains("youtube.com")==true || u.host?.contains("youtu.be")==true){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u.toString())));true}else false } }
 web.loadUrl("file:///android_asset/index.html")
 }
 @Deprecated("Deprecated in Java") override fun onBackPressed(){if(::web.isInitialized && web.canGoBack())web.goBack() else super.onBackPressed()}
}