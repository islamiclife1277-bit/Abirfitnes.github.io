ABIR FITNESS PRO v2.0

Features:
- Liquid-glass inspired dark UI with floating capsule bottom navigation
- Bangla / English toggle
- Original user-supplied V-Taper routine retained
- Exercise library with YouTube tutorial search links
- Completion tracking and progress percentage saved locally
- Rest timer
- Profile page (name, age, optional height/weight, experience)
- Routine builder based on goal, experience, available equipment and days per week
- Offline routine and local profile data

Important:
- Height and weight are optional profile details. The routine builder does NOT use height/weight to determine body ideals, weight-loss targets or medical exercise prescriptions. It uses goal, experience, equipment and weekly availability.
- Routine builder currently generates a general sample preview, not a clinically individualized plan.
- YouTube buttons open YouTube search results; an internet connection is needed.
- To build APK: open this folder in Android Studio on a computer, sync Gradle, install Android SDK 35 if requested, then Build > Build Bundle(s) / APK(s) > Build APK(s).
- APK is not precompiled in this environment.
